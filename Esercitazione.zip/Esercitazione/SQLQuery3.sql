select*
from pr

select*
from sa

select*
from re




--verifico che le Primary key delle tabelle siano uniche 

SELECT COUNT(IDProdotto) AS NumeroDuplicati
FROM pr
GROUP BY IDProdotto
HAVING COUNT(IDProdotto) > 1;

SELECT COUNT(IDVendita) AS NumeroDuplicati
FROM sa
GROUP BY IDVendita
HAVING COUNT(IDVendita) > 1;

SELECT COUNT(IDVendita) AS NumeroDuplicati
FROM re
GROUP BY IDVendita
HAVING COUNT(IDVendita) > 1;
-- non ci sono duplicati nelle Primary Key


-- elenco delle transazione con campo che mostra se � stata effettuata pi� di 180 giorni fa


select	pr.IDProdotto, 
		pr.Nome_prodotto, 
		pr.Tipologia,
		sa.Data_Vendita,
		re.Nazione,
		re.Zona,
		CASE WHEN DATEDIFF(DAY, sa.Data_Vendita, GETDATE()) > 180 THEN 1 ELSE 0 END AS PassatiPi�Di180Giorni



from pr

Join sa ON pr.IDProdotto = sa.IDProdotto
Join re ON sa.IDVendita = re.IDVendita
ORDER BY sa.Data_Vendita DESC;

-- Elenco dei Prodotti venduti e il loro fatturato annuo


select	pr.Nome_prodotto,
		YEAR(sa.Data_Vendita) AS Anno_della_Vendita,
		SUM(pr.Prezzo) AS Fatturato_Totale_Prodotto


from pr

Join sa ON pr.IDProdotto = sa.IDProdotto

GROUP BY
		pr.Nome_prodotto,
		YEAR(sa.Data_Vendita)

ORDER BY
		pr.Nome_prodotto,
		YEAR(sa.Data_Vendita);


-- Fatturato totale per stato ordinato per data e per fatturato decrescente 

select	re.Nazione,
		YEAR(sa.Data_Vendita) AS Anno_Della_Vendita,
		SUM(pr.Prezzo) AS Fatturato_Totale

from pr

Join sa ON pr.IDProdotto = sa.IDProdotto
Join re ON sa.IDVendita = re.IDVendita

GROUP BY
		re.Nazione,
		YEAR(sa.Data_Vendita)

ORDER BY
		Anno_Della_Vendita ASC,
		Fatturato_Totale DESC;

-- categoria maggiormente richiesta/venduta

select	pr.Tipologia,
		SUM(1) AS Quantit�Totale
from pr

Join sa ON pr.IDProdotto = sa.IDProdotto
Join re ON sa.IDVendita = re.IDVendita

GROUP BY
    pr.Tipologia
ORDER BY
    Quantit�Totale DESC

/* mostrare se presenti prodotti invenduti in due alternative possibili
	Alternativa 1 */


select	 pr.Nome_prodotto

from pr
WHERE NOT EXISTS (
    SELECT 1
    FROM sa
    WHERE sa.IDProdotto = pr.IDProdotto
);

-- ALTERNATIVA 2
select	 pr.Nome_prodotto

from pr

LEFT JOIN sa ON pr.IDProdotto = sa.IDProdotto

WHERE sa.IDProdotto IS NULL;


-- Mostrare i prodotti con la data di vendita pi� recente 

select	pr.Nome_prodotto,
		MAX(sa.Data_Vendita) AS Ultima_Data_Di_Vendita

FROM pr

LEFT JOIN sa ON pr.IDProdotto = sa.IDProdotto

GROUP BY
		pr.Nome_prodotto;


-- creare una versione denormalizzata delle informazioni utili utilizzando una view

CREATE VIEW Vista_Prodotti_Denormalizzata AS

select	pr.IDProdotto,
		pr.Nome_prodotto,
		pr.Tipologia

from pr


select *
from Vista_Prodotti_Denormalizzata;


-- stessa cosa di prima per� ora con le informazioni geografiche

CREATE VIEW Vista_Geografica_Denormalizzata AS

select distinct re.Nazione,
				re.Zona
    
from re



select * 
from Vista_Geografica_Denormalizzata;


