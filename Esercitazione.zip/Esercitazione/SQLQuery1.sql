Create database test;


Create table Product
(
	IDProdotto int NOT NULL PRIMARY KEY,
	Prezzo int,
	Tipologia varchar(50) NOT NULL,
	Nome_Prodotto varchar(50),
);


create table Sales
(
	IDVendita int NOT NULL PRIMARY KEY,
	IDCliente int NOT NULL,
	IDProdotto int NOT NULL,
	Data_vendita datetime,
);

create table Region
(
	Zona varchar(50) NOT NULL PRIMARY KEY,
	IDStato int NOT NULL,
	IDVendita int NOT NULL,
	Nazione varchar(50),
);



select *
from Product

select *
from Sales

select *
from Region


